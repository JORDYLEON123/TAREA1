// Ejercicio 11: Solicitar al usuario una distancia en metros y mostrarla en centímetros.
//Inicio del programa
//    Escribir "Por favor ingresa la distancia en metros:"  // Entrada de datos
//    Leer metros  // Proceso de entrada
//    centimetros = metros * 100  // Proceso de convertir la distancia a centímetros
//    Escribir "La distancia en centímetros es: " + centimetros  // Salida de datos con la distancia en centímetros
//Fin del programa

// Solicitar al usuario una distancia en metros
var d = parseFloat(prompt("Ingresa la distancia en metros:"));

// Convertir la distancia a centímetros
var c = d * 100;

// Mostrar la distancia en centímetros
alert("La distancia de " + d + " metros equivale a " + c + " centímetros.");
