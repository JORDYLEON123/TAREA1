// Ejercicio 1: Pedir al usuario un número y mostrar si es mayor o menor que 10.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//    Si numero > 10 entonces  // Proceso de comparación
//        Escribir "El número es mayor que 10."  // Salida de datos
//    Sino si numero < 10 entonces
//        Escribir "El número es menor que 10."  // Salida de datos
//    Sino
//        Escribir "El número es igual a 10."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario un número
var n = parseFloat(prompt("Por favor, ingresa un número:"));

// Verificar si el número es mayor o menor que 10 y mostrar el resultado
if (n > 10) {
    alert("El número ingresado es mayor que 10.");
} else { 
    alert("El número ingresado es menor que 10.");
}
