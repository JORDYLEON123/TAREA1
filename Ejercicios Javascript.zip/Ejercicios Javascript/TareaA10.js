// Ejercicio 10: Pedir al usuario dos números y mostrar el mayor.
//Inicio del programa
//    Escribir "Por favor ingresa el primer número:"  // Entrada de datos
//    Leer num1  // Proceso de entrada
//    Escribir "Ahora ingresa el segundo número:"  // Entrada de datos
//    Leer num2  // Proceso de entrada
//    Si num1 > num2 entonces  // Proceso de comparar los números
//        Escribir "El número mayor es: " + num1  // Salida de datos mostrando el número mayor
//    Sino
//        Escribir "El número mayor es: " + num2  // Salida de datos mostrando el número mayor
//    Fin Si
//Fin del programa

// Solicitar al usuario dos números
var n1 = parseFloat(prompt("Ingresa el primer número:"));
var n2 = parseFloat(prompt("Ingresa el segundo número:"));

// Comparar los números y mostrar el mayor
if (n1 > n2) {
    alert("El número mayor es: " + n1);
} else {
    alert("El número mayor es: " + n2);
}