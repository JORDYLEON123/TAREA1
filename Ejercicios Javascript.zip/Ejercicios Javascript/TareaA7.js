// Ejercicio 7: Solicitar al usuario una temperatura en grados Celsius y mostrarla en grados Fahrenheit.
//Inicio del programa
//    Escribir "Por favor ingresa la temperatura en grados Celsius:"  // Entrada de datos
//    Leer celsius  // Proceso de entrada
//    fahrenheit = (celsius * 9/5) + 32  // Proceso de convertir la temperatura a Fahrenheit
//    Escribir "La temperatura en grados Fahrenheit es: " + fahrenheit  // Salida de datos con la temperatura en Fahrenheit
//Fin del programa

// Solicitar al usuario una temperatura en grados Celsius
var c = parseFloat(prompt("Por favor, ingresa la temperatura en grados Celsius:"));

// Convertir la temperatura a grados Fahrenheit
var f = (c * 9/5) + 32;

// Mostrar la temperatura en grados Fahrenheit
alert("La temperatura de " + c + " grados Celsius equivale a " + f + " grados Fahrenheit.");
