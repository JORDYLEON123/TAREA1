// Ejercicio 2: Solicitar al usuario su edad y mostrar si es mayor o menor de edad.
//Inicio del programa
//    Escribir "Por favor ingresa tu edad:"  // Entrada de datos
//    Leer edad  // Proceso de entrada
//    Si edad >= 18 entonces  // Proceso de comparación
//        Escribir "Eres mayor de edad."  // Salida de datos
//    Sino
//        Escribir "Eres menor de edad."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario su edad
var edad = parseInt(prompt("Ingrese su edad:"));

// Verificar si la edad es mayor o menor de edad y mostrar el resultado
if (edad > 17) {
    alert("Eres mayor de edad.");
} else {
    alert("Eres menor de edad.");
}