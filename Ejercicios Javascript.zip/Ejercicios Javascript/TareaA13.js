// Ejercicio 13: Dado un arreglo de 5 nombres presentarlos todos
//Inicio del programa
//    nombres = [nombre1, nombre2, nombre3, nombre4, nombre5]  // Proceso de inicializar un arreglo con nombres
//    Para cada nombre en nombres hacer  // Proceso de iterar sobre cada nombre en el arreglo
//        Escribir nombre  // Salida de datos mostrando el nombre
//    Fin Para

//    // Ejercicio
//Fin del programa


// Definir un arreglo de nombres
var nombres = ["Angel", "Luis", "Ana", "María", "José"];

// Presentar los nombres uno por uno
console.log("Los nombres son:");
for (var i = 0; i < nombres.length; i++) {
    console.log(nombres[i]);
}