// Ejercicio 6: Pedir al usuario dos números y mostrar el resultado de multiplicarlos.
//Inicio del programa
//    Escribir "Por favor ingresa el primer número:"  // Entrada de datos
//    Leer num1  // Proceso de entrada
//    Escribir "Ahora ingresa el segundo número:"  // Entrada de datos
//    Leer num2  // Proceso de entrada
//    producto = num1 * num2  // Proceso de multiplicar los números
//    Escribir "El resultado de la multiplicación es: " + producto  // Salida de datos con el resultado de la multiplicación
//Fin del programa

// Solicitar al usuario dos números
var n1 = parseFloat(prompt("Por favor, ingresa el primer número:"));
var n2 = parseFloat(prompt("Ahora, ingresa el segundo número:"));

// Calcular el resultado de la multiplicación
var r = n1 * n2;

// Mostrar el resultado
alert("El resultado de multiplicar " + n1 + " por " + n2 + " es: " + r);
