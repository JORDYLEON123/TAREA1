// Ejercicio 17: Determinar ganancia de un productor de bananos
//Inicio del programa
//    // Etapa de entrada
//    Leer tipo_de_banano, tamaño_de_banano, precio_inicial
//    // Proceso
//    si tipo_de_banano = "A" entonces
//        si tamaño_de_banano = 1 entonces
//            precio_final = precio_inicial + 2
//        sino
//            precio_final = precio_inicial + 3
//    sino
//        si tamaño_de_banano = 1 entonces
//            precio_final = precio_inicial - 3
//        sino
//            precio_final = precio_inicial - 5
//    // Etapa de salida
//    Mostrar precio_final
//Fin del programa


// Solicitar al usuario el precio de venta del vehículo y su año de fabricación
var precioVenta = parseFloat(prompt("Ingresa el precio de venta del vehículo:"));
var anoFabricacion = parseInt(prompt("Ingresa el año de fabricación del vehículo:"));

// Verificar si el año de fabricación es anterior a 2010 y aplicar el descuento si es necesario
if (anoFabricacion < 2010) {
    var descuento = precioVenta * 0.10; // Calcular el descuento del 10%
    var precioFinal = precioVenta - descuento; // Calcular el precio final con descuento
    alert("Debido a que el vehículo es fabricado antes de 2010, se aplicó un descuento del 10%. El precio final es: $" + precioFinal.toFixed(2));
} else {
    alert("El año de fabricación del vehículo es posterior a 2010. No se aplicó ningún descuento. El precio final es: $" + precioVenta.toFixed(2));
}
