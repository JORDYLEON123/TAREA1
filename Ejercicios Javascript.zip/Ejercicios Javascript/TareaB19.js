// Ejercicio 19: Comparar primer y último elemento de un arreglo
//Inicio del programa
//    // Etapa de entrada
//    Leer arreglo
//    // Proceso
//    si arreglo[0] > arreglo[4] entonces
//        resultado = Verdadero
//    sino
//        resultado = Falso
//    // Etapa de salida
//    Mostrar resultado
//Fin del programa


// Definir un arreglo de 5 elementos (puedes cambiar los valores según sea necesario)
var arreglo = [8, 7, 0, 3, 4];

// Obtener el primer y el último elemento del arreglo
var primerElemento = arreglo[0];
var ultimoElemento = arreglo[arreglo.length - 1];

// Comparar si el primer elemento es mayor que el último elemento
if (primerElemento > ultimoElemento) {
    console.log("El primer elemento (" + primerElemento + ") es mayor que el último elemento (" + ultimoElemento + ").");
} else {
    console.log("El primer elemento (" + primerElemento + ") no es mayor que el último elemento (" + ultimoElemento + ").");
}
