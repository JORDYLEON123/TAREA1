// Ejercicio 12: Pedir al usuario el monto total de una factura y el porcentaje de IVA aplicado. Luego, calcular y mostrar el monto total a pagar incluyendo el IVA.
//Inicio del programa
//    Escribir "Por favor ingresa el monto total de la factura:"  // Entrada de datos
//    Leer monto_factura  // Proceso de entrada
//    Escribir "Por favor ingresa el porcentaje de IVA aplicado:"  // Entrada de datos
//    Leer porcentaje_iva  // Proceso de entrada
//    monto_total = monto_factura * (1 + porcentaje_iva / 100)  // Proceso de cálculo del monto total
//    Escribir "El monto total a pagar incluyendo el IVA es: " + monto_total  // Salida de datos
//Fin del programa


var montoTotal = parseFloat(prompt("Ingrese el monto total de la factura:"));
var porcentajeIVA = parseFloat(prompt("Ingrese el porcentaje de IVA aplicado (%):"));

// Calcular el monto del IVA
var montoIVA = montoTotal * (porcentajeIVA / 100);

// Calcular el monto total a pagar incluyendo el IVA
var montoTotalPagar = montoTotal + montoIVA;

// Mostrar el monto total a pagar incluyendo el IVA
alert("El monto total a pagar incluyendo el IVA es: $" + montoTotalPagar.toFixed(2));
