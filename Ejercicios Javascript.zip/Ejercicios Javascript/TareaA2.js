// Ejercicio 2: Pedir dos palabras y presentarlas concatenadas
//Inicio del programa
//    Escribir "Por favor ingresa la primera palabra:"  // Entrada de datos
//    Leer palabra1  // Proceso de entrada
//    Escribir "Ahora ingresa la segunda palabra:"  // Entrada de datos
//    Leer palabra2  // Proceso de entrada
//    Escribir "La concatenación de las palabras es: " + palabra1 + palabra2  // Salida de datos con la concatenación
//Fin del programa

// Pedir al usuario dos palabras
var p1 = prompt("Ingrese la primera palabra:");
var p2 = prompt("Ingrese la segunda palabra:");

// Presentar las palabras concatenadas
alert("Las palabras concatenadas son: " + p1 + " " + p2);