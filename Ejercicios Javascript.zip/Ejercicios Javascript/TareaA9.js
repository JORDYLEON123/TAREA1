// Ejercicio 9: Solicitar al usuario un número y mostrar su tabla de multiplicar del 1 al 10.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//        Escribir numero + " x 1 = " + numero * 1  // Salida de datos mostrando la tabla de multiplicar
//        Escribir numero + " x 2 = " + numero * 3
//        Escribir numero + " x 3 = " + numero * 4
//        Escribir numero + " x 4 = " + numero * 5
//        Escribir numero + " x 5 = " + numero * 6
//        Escribir numero + " x 6 = " + numero * 7
//        Escribir numero + " x 7 = " + numero * 8
//        Escribir numero + " x 8 = " + numero * 9
//        Escribir numero + " x 9 = " + numero * 10
//Fin del programa


// Solicitar al usuario un número
var n = parseInt(prompt("Por favor, ingresa un número:"));

// Mostrar la tabla de multiplicar del número ingresado
document.write("<h2>Tabla de multiplicar del " + n + ":</h2>");
document.write(n + " x 1 = " + n * 1 + "<br>");
document.write(n + " x 2 = " + n * 2 + "<br>");
document.write(n + " x 3 = " + n * 3 + "<br>");
document.write(n + " x 4 = " + n * 4 + "<br>");
document.write(n + " x 5 = " + n * 5 + "<br>");
document.write(n + " x 6 = " + n * 6 + "<br>");
document.write(n + " x 7 = " + n * 7 + "<br>");
document.write(n + " x 8 = " + n * 8 + "<br>");
document.write(n + " x 9 = " + n * 9 + "<br>");
document.write(n + " x 10 = " + n * 10);