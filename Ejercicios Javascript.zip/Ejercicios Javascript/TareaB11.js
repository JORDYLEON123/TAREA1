// Ejercicio 11: Solicitar al usuario un número y mostrar si es un número de un solo dígito.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//    Si numero >= 0 y numero <= 9 entonces  // Proceso de determinar un solo dígito
//        Escribir "El número es de un solo dígito."  // Salida de datos
//    Sino
//        Escribir "El número no es de un solo dígito."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario un número
var n = parseInt(prompt("Ingrese un número:"));

// Verificar si el número es de un solo dígito y mostrar el resultado
if (n >= 0 && n <= 9) {
    alert("El número ingresado es de un solo dígito.");
} else {
    alert("El número ingresado no es de un solo dígito.");
}
