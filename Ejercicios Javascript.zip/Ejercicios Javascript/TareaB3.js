// Ejercicio 3: Pedir al usuario un número y mostrar si es par o impar.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//    Si numero % 2 == 0 entonces  // Proceso de determinar paridad
//        Escribir "El número es par."  // Salida de datos
//    Sino
//        Escribir "El número es impar."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario un número
var numero = parseInt(prompt("Ingrese un número:"));

// Verificar si el número es par o impar y mostrar el resultado
if (numero % 2 === 0) {
    alert("El número ingresado es par.");
} else {
    alert("El número ingresado es impar.");
}
