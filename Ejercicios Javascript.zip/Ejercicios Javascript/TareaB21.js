// Ejercicio 21: Encontrar el mayor elemento de un arreglo
//Inicio del programa
//    // Etapa de entrada
//    Leer arreglo
//    // Proceso
//    mayor = arreglo[0]
//    para cada elemento en arreglo hacer
//        si elemento > mayor entonces
//            mayor = elemento
//    // Etapa de salida
//    Mostrar mayor
//Fin del programa


// Definir un arreglo de 3 elementos (puedes cambiar los valores según sea necesario)
var arreglo = [3, 8, -3];

// Inicializar una variable para almacenar el elemento mayor y asignarle el primer elemento del arreglo
var mayor = arreglo[0];

// Comparar con los otros elementos del arreglo para encontrar el mayor
for (var i = 1; i < arreglo.length; i++) {
    if (arreglo[i] > mayor) {
        mayor = arreglo[i];
    }
}

// Mostrar el elemento mayor
console.log("El elemento mayor en el arreglo es: " + mayor);
