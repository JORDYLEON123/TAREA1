// Ejercicio 8: Pedir al usuario un número y mostrar si es múltiplo de 3.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//    Si numero % 3 == 0 entonces  // Proceso de determinar múltiplo de 3
//        Escribir "El número es múltiplo de 3."  // Salida de datos
//    Sino
//        Escribir "El número no es múltiplo de 3."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario un número
var n = parseInt(prompt("Por favor, ingresa un número:"));

// Verificar si el número es múltiplo de 3 y mostrar el resultado
if (n % 3 === 0) {
    alert("El número ingresado es múltiplo de 3.");
} else {
    alert("El número ingresado no es múltiplo de 3.");
}
