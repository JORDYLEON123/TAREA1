// Ejercicio 14: Dado un arreglo de 5 elementos, presentar el primero, el del medio y el último
//Inicio del programa
//    elementos = [elem1, elem2, elem3, elem4, elem5]  // Inicialización del arreglo
//    Escribir "El primer elemento es: " + elementos[0]  // Salida de datos mostrando el primer elemento
//    Escribir "El elemento del medio es: " + elementos[2]  // Salida de datos mostrando el elemento del medio
//    Escribir "El último elemento es: " + elementos[4]  // Salida de datos mostrando el último elemento
//Fin del programa


// Definir un arreglo de 5 elementos
var elementos = [4, 7, -2, 3, 1];

// Presentar el primer elemento
console.log("El primer elemento es:", elementos[0]);

// Presentar el elemento del medio
var indiceMedio = Math.floor(elementos.length / 2); // Obtener el índice del elemento del medio
console.log("El elemento del medio es:", elementos[indiceMedio]);

// Presentar el último elemento
console.log("El último elemento es:", elementos[elementos.length - 1]);
