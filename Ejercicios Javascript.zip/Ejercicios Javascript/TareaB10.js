// Ejercicio 10: Pedir al usuario un número y mostrar si es mayor, menor o igual a 100.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//    Si numero > 100 entonces  // Proceso de comparación
//        Escribir "El número es mayor que 100."  // Salida de datos
//    Sino si numero < 100 entonces
//        Escribir "El número es menor que 100."  // Salida de datos
//    Sino
//        Escribir "El número es igual a 100."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario un número
var numero = parseFloat(prompt("Ingrese un número:"));

// Verificar si el número es mayor, menor o igual a 100 y mostrar el resultado
if (numero > 100) {
    alert("El número ingresado es mayor que 100.");
} else if (numero < 100) {
    alert("El número ingresado es menor que 100.");
} else {
    alert("El número ingresado es igual a 100.");
}