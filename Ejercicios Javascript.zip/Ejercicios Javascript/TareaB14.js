// Ejercicio 14: Pedir al usuario su nota en un examen y determinar si ha aprobado o reprobado, considerando que la nota mínima de aprobación es 60 puntos.
//Inicio del programa
//    Escribir "Por favor ingresa tu nota en el examen:"  // Entrada de datos
//    Leer nota_examen  // Proceso de entrada
//    Si nota_examen >= 60 entonces  // Proceso de comparación
//        Escribir "¡Felicidades! Has aprobado el examen."  // Salida de datos
//    Sino
//        Escribir "Lo siento, has reprobado el examen."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario su nota en el examen
var nota = parseFloat(prompt("Ingrese tu nota en el examen:"));

// Determinar si ha aprobado o reprobado y mostrar el resultado
if (nota >= 60) {
    alert("¡Felicidades! Has aprobado el examen.");
} else {
    alert("Lo siento, has reprobado el examen. ¡Ánimo para la próxima!");
}
