// Ejercicio 13: Solicitar al usuario el precio de un producto y el porcentaje de descuento aplicado. Calcular y mostrar el precio final luego de aplicar el descuento.
//    Inicio del programa
//    Escribir "Por favor ingresa el precio del producto:"  // Entrada de datos
//    Leer precio_producto  // Proceso de entrada
//    Escribir "Por favor ingresa el porcentaje de descuento aplicado:"  // Entrada de datos
//    Leer porcentaje_descuento  // Proceso de entrada
//    precio_final = precio_producto * (1 - porcentaje_descuento / 100)  // Proceso de cálculo del precio final
//    Escribir "El precio final luego de aplicar el descuento es: " + precio_final  // Salida de datos
//Fin del programa


// Solicitar al usuario el precio del producto y el porcentaje de descuento
var precioProducto = parseFloat(prompt("Por favor, ingresa el precio del producto:"));
var porcentajeDescuento = parseFloat(prompt("Por favor, ingresa el porcentaje de descuento aplicado (%):"));

// Calcular el monto del descuento
var montoDescuento = precioProducto * (porcentajeDescuento / 100);

// Calcular el precio final luego de aplicar el descuento
var precioFinal = precioProducto - montoDescuento;

// Mostrar el precio final luego de aplicar el descuento
alert("El precio final luego de aplicar el descuento es: $" + precioFinal.toFixed(2));
