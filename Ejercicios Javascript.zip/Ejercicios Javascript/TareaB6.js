// Ejercicio 6: Solicitar al usuario un carácter y mostrar si es una vocal o consonante.
//Inicio del programa
//    Escribir "Por favor ingresa un carácter:"  // Entrada de datos
//    Leer caracter  // Proceso de entrada
//    Si caracter es una vocal entonces  // Proceso de determinar tipo de carácter
//        Escribir "El carácter es una vocal."  // Salida de datos
//    Sino
//        Escribir "El carácter es una consonante."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario un carácter
var c = prompt("Ingrese un carácter:");

// Convertir el carácter a minúscula para simplificar la comparación
c = c.toLowerCase();

// Verificar si el carácter es una vocal o consonante y mostrar el resultado
if (c === "a" || c === "e" || c === "i" || c === "o" || c === "u") {
    alert("El carácter ingresado es una vocal.");
} else{
    alert("El carácter ingresado es una consonante.");
}
