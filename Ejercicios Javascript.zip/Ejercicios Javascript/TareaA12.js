// Ejercicio 12: Pedir 5 números y asignarlos en un arreglo
//Inicio del programa
//    arreglo = arreglo vacío  // Proceso de inicializar un arreglo vacío
//    Para i desde 1 hasta 5 hacer  // Proceso de iterar cinco veces
//        Escribir "Por favor ingresa el número " + i + ":"  // Entrada de datos
//        Leer numero  // Proceso de entrada
//        Agregar numero al final de arreglo  // Proceso de agregar número al arreglo
//    Fin Para
//    Escribir "Los números ingresados son: " + arreglo  // Salida de datos mostrando los números ingresados en el arreglo
//Fin del programa

// Crear un arreglo para almacenar los números
var v = [];

// Solicitar al usuario 5 números y asignarlos al arreglo
for (var i = 0; i < 5; i++) {
    var numero = parseFloat(prompt("Ingresa el número " + (i + 1) + ":"));
    v.push(numero);
}

// Mostrar el arreglo de números
console.log("Los números ingresados son:", v);
