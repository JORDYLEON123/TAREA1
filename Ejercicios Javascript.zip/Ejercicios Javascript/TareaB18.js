// Ejercicio 18: Determinar presupuesto de evento con tarifas de banquetes
//Inicio del programa
//    // Etapa de entrada
//    Leer numero_de_personas
//    // Proceso
//    si numero_de_personas <= 100 entonces
//        presupuesto = numero_de_personas * 20
//    sino si numero_de_personas <= 200 entonces
//        presupuesto = numero_de_personas * 15
//    sino
//        presupuesto = numero_de_personas * 10
//    presupuesto_con_iva = presupuesto + (presupuesto * 0.15)
//    // Etapa de salida
//    Mostrar presupuesto_con_iva
//Fin del programa


// Solicitar al usuario el número de personas en el evento
var p = parseInt(prompt("Ingresa el número de personas en el evento:"));

// Definir el costo por platillo por persona según el número de personas
var costoPorPlatillo;
if (p <= 100) {
    costoPorPlatillo = 20; // Costo por platillo por persona para hasta 100 personas
} else if (p > 100 && p <= 200) {
    costoPorPlatillo = 15; // Costo por platillo por persona para 101 a 200 personas
} else {
    costoPorPlatillo = 10; // Costo por platillo por persona para más de 200 personas
}

// Calcular el costo total del evento sin incluir el IVA
var costoTotalSinIVA = costoPorPlatillo * p;

// Calcular el monto del IVA (15% del costo total sin incluir el IVA)
var montoIVA = costoTotalSinIVA * 0.15;

// Calcular el costo total del evento incluyendo el IVA
var costoTotalConIVA = costoTotalSinIVA + montoIVA;

// Mostrar el presupuesto que se debe presentar al cliente
alert("El presupuesto para el evento, incluyendo el 15% de IVA, es de: $" + costoTotalConIVA.toFixed(2));
