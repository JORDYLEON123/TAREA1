// Ejercicio 20: Verificar paridad del primer y último elemento de un arreglo
//Inicio del programa
//    // Etapa de entrada
//    Leer arreglo
//    // Proceso
//    si arreglo[0] es par y arreglo[4] es impar entonces
//        resultado = Verdadero
//    sino
//        resultado = Falso
//    // Etapa de salida
//    Mostrar resultado
//Fin del programa


// Definir un arreglo de 5 elementos (puedes cambiar los valores según sea necesario)
var arreglo = [7, 4, -1, 3, 2];

// Obtener el primer y el último elemento del arreglo
var primerElemento = arreglo[0];
var ultimoElemento = arreglo[arreglo.length - 1];

// Verificar si el primer elemento es par y el último elemento es impar
if (primerElemento % 2 === 0 && ultimoElemento % 2 !== 0) {
    console.log("El primer elemento (" + primerElemento + ") es par y el último elemento (" + ultimoElemento + ") es impar.");
} else {
    console.log("El primer elemento (" + primerElemento + ") no es par o el último elemento (" + ultimoElemento + ") no es impar.");
}
