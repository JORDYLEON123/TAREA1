// Ejercicio 15: Solicitar al usuario el precio de venta de un vehículo nuevo y su año de fabricación. Si el año de fabricación es anterior a 2010, aplicar un descuento del 10% sobre el precio de venta y mostrar el precio final.
//Inicio del programa
//    Escribir "Por favor ingresa el precio de venta del vehículo nuevo:"  // Entrada de datos
//    Leer precio_vehiculo  // Proceso de entrada
//    Escribir "Por favor ingresa el año de fabricación del vehículo:"  // Entrada de datos
//    Leer año_fabricacion  // Proceso de entrada
//    Si año_fabricacion < 2010 entonces  // Proceso de comparación
//        descuento = precio_vehiculo * 0.10  // Proceso de cálculo del descuento
//        precio_final = precio_vehiculo - descuento  // Proceso de cálculo del precio final con descuento
//        Escribir "El precio final del vehículo con descuento es: " + precio_final  // Salida de datos
//    Sino
//        Escribir "El precio final del vehículo es: " + precio_vehiculo  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario su sueldo mensual
var sueldoMensual = parseFloat(prompt("Ingrese tu sueldo mensual:"));

// Calcular el sueldo anual
var sueldoAnual = sueldoMensual * 12;

// Verificar si el sueldo anual supera los $30,000
if (sueldoAnual > 30000) {
    // Calcular el excedente sobre los $30,000
    var excedente = sueldoAnual - 30000;

    // Calcular el impuesto del 15% sobre el excedente
    var impuesto = excedente * 0.15;

    // Calcular el sueldo neto anual restando el impuesto al sueldo anual
    var sueldoNetoAnual = sueldoAnual - impuesto;

    alert("Tu sueldo neto anual, después de aplicar un impuesto del 15% sobre el excedente de $30,000, es: $" + sueldoNetoAnual.toFixed(2));
} else {
    // Si el sueldo anual no supera los $30,000, no se aplica ningún impuesto
    alert("Tu sueldo anual es: $" + sueldoAnual.toFixed(2) + ". No se aplicó ningún impuesto, ya que no supera los $30,000.");
}
