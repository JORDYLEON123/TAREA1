// Ejercicio 8: Pedir al usuario su nombre y mostrarlo tres veces en la pantalla.
//Inicio del programa
//    Escribir "Por favor ingresa tu nombre:"  // Entrada de datos
//    Leer nombre  // Proceso de entrada
//    Escribir nombre  // Salida de datos mostrando el nombre
//    Escribir nombre  // Salida de datos mostrando el nombre
//    Escribir nombre  // Salida de datos mostrando el nombre
//Fin del programa

// Pedir al usuario su nombre
var n = prompt("Ingresa tu nombre:");

// Mostrar el nombre tres veces en la pantalla
document.write(n + "<br>");
document.write(n + "<br>");
document.write(n + "<br>");