// Ejercicio 15: Dado un arreglo de 5 elementos, cambiar los valores del primer y último elemento entre sí
//Inicio del programa
//    Escribir "Por favor ingresa los 5 elementos del arreglo:"  // Entrada de datos
//    Para i desde 0 hasta 4 hacer  // Proceso de iterar sobre los elementos del arreglo
//        Leer elementos[i]  // Proceso de entrada
//    Fin Para
//    temp = elementos[0]  // Almacenar temporalmente el primer elemento
//    elementos[0] = elementos[4]  // Asignar el último elemento al primer elemento
//    elementos[4] = temp  // Asignar el primer elemento al último elemento
//    Escribir "Los valores del primer y último elemento han sido intercambiados."  // Salida de datos indicando el intercambio
//Fin del programa


// Definir un arreglo de 5 elementos
var elementos = [4, 7, 11, 0, 6];

// Intercambiar los valores del primer y último elemento
var temp = elementos[0]; // Almacenar el valor del primer elemento en una variable temporal
elementos[0] = elementos[elementos.length - 1]; // Asignar el valor del último elemento al primer elemento
elementos[elementos.length - 1] = temp; // Asignar el valor almacenado en la variable temporal al último elemento

// Presentar el arreglo actualizado
console.log("Arreglo después del intercambio:", elementos);
