// Ejercicio 5: Solicitar al usuario su edad y mostrar un mensaje indicando cuántos años tendrá en el próximo año.
//Inicio del programa
//    Escribir "Por favor ingresa tu edad:"  // Entrada de datos
//    Leer edad  // Proceso de entrada
//    edad_proximo_anio = edad + 1  // Proceso de calcular la edad del próximo año
//    Escribir "El próximo año tendrás " + edad_proximo_anio + " años."  // Salida de datos con la edad del próximo año
//Fin del programa

// Solicitar al usuario su edad
var edad = parseInt(prompt("Ingrese su edad:"));

// Calcular la edad del próximo año
var años = edad + 1;

// Mostrar un mensaje con la edad del próximo año
alert("El próximo año tendrás " + años + " años.");
