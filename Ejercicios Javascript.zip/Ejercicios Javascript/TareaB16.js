// Ejercicio 16: Determinar sueldo neto anual con impuesto
//Inicio del programa
//    // Etapa de entrada
//    Leer sueldo_mensual
//    // Proceso
//    sueldo_anual = sueldo_mensual * 12
//    si sueldo_anual > 30000 entonces
//        impuesto = (sueldo_anual - 30000) * 0.15
//        sueldo_neto_anual = sueldo_anual - impuesto
//    sino
//        sueldo_neto_anual = sueldo_anual
//    // Etapa de salida
//    Mostrar sueldo_neto_anual
//Fin del programa


// Solicitar al usuario el tipo (A o B) y el tamaño (1 o 2) del banano
var tipoBanano = prompt("Ingresa el tipo de banano (A o B):").toUpperCase();
var tamanoBanano = parseInt(prompt("Ingresa el tamaño del banano (1 o 2):"));

// Definir el precio inicial del kilo de banano según el tipo
var precioInicial;
if (tipoBanano === "A") {
    precioInicial = 10; // Precio inicial para el tipo A
} else if (tipoBanano === "B") {
    precioInicial = 8; // Precio inicial para el tipo B
} else {
    alert("Tipo de banano no válido. Por favor, ingresa A o B.");
}

// Determinar la ganancia según el tipo y tamaño del banano
var ganancia;
if (tipoBanano === "A" && tamanoBanano === 1) {
    ganancia = precioInicial + 2; // Se le cargan $2 al precio inicial para el tamaño 1 del tipo A
} else if (tipoBanano === "A" && tamanoBanano === 2) {
    ganancia = precioInicial + 3; // Se le cargan $3 al precio inicial para el tamaño 2 del tipo A
} else if (tipoBanano === "B" && tamanoBanano === 1) {
    ganancia = precioInicial - 3; // Se rebajan $3 al precio inicial para el tamaño 1 del tipo B
} else if (tipoBanano === "B" && tamanoBanano === 2) {
    ganancia = precioInicial - 5; // Se rebajan $5 al precio inicial para el tamaño 2 del tipo B
} else {
    alert("Tamaño de banano no válido. Por favor, ingresa 1 o 2.");
}

// Mostrar la ganancia obtenida por el productor
if (ganancia !== undefined) {
    alert("La ganancia obtenida por el productor es: $" + ganancia.toFixed(2) + " por kilo de banano.");
}
