// Ejercicio 9: Solicitar al usuario un número y mostrar si es divisible por 2.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//    Si numero % 2 == 0 entonces  // Proceso de determinar divisibilidad por 2
//        Escribir "El número es divisible por 2."  // Salida de datos
//    Sino
//        Escribir "El número no es divisible por 2."  // Salida de datos
//    Fin Si
//Inicio del programa


// Solicitar al usuario un número
var n = parseInt(prompt("Ingrese un número:"));

// Verificar si el número es divisible por 2 y mostrar el resultado
if (n % 2 === 0) {
    alert("El número ingresado es divisible por 2.");
} else {
    alert("El número ingresado no es divisible por 2.");
}
