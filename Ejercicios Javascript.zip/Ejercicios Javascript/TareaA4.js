// Ejercicio 4: Pedir al usuario un número y mostrar su doble.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//    doble = numero * 2  // Proceso de calcular el doble del número
//    Escribir "El doble del número es: " + doble  // Salida de datos con el doble del número
//Fin del programa

// Pedir al usuario un número
var n = parseFloat(prompt("Ingrese un número:"));

// Calcular el doble del número
var d = n * 2;

// Mostrar el doble
alert("El doble del número ingresado es: " + d);