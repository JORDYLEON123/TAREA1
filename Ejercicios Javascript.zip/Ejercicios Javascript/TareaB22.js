// Ejercicio 22: Calcular la suma de elementos de un arreglo
//Inicio del programa
//    // Etapa de entrada
//    Leer arreglo
//    // Proceso
//    suma = 0
//    para cada elemento en arreglo hacer
//        suma = suma + elemento
//    // Etapa de salida
//    Mostrar suma
//Fin del programa


// Definir un arreglo de 5 elementos (puedes cambiar los valores según sea necesario)
var arreglo = [1, 6, -4, 5, 2];

// Inicializar una variable para almacenar la suma e inicializarla en 0
var suma = 0;

// Recorrer el arreglo y sumar cada elemento
for (var i = 0; i < arreglo.length; i++) {
    suma += arreglo[i];
}

// Mostrar la suma de los elementos del arreglo
console.log("La suma de los elementos del arreglo es: " + suma);
