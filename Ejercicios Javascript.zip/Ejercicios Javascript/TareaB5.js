// Ejercicio 5: Pedir al usuario dos números y mostrar si son iguales o diferentes.
//Inicio del programa
//    Escribir "Por favor ingresa el primer número:"  // Entrada de datos
//    Leer num1  // Proceso de entrada
//    Escribir "Por favor ingresa el segundo número:"  // Entrada de datos
//    Leer num2  // Proceso de entrada
//    Si num1 == num2 entonces  // Proceso de comparación
//        Escribir "Los números son iguales."  // Salida de datos
//    Sino
//        Escribir "Los números son diferentes."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario dos números
var n1 = parseFloat(prompt("Ingrese el primer número:"));
var n2 = parseFloat(prompt("Ingrese el segundo número:"));

// Verificar si los números son iguales o diferentes y mostrar el resultado
if (n1 === n2) {
    alert("Los números ingresados son iguales.");
} else {
    alert("Los números ingresados son diferentes.");
}
