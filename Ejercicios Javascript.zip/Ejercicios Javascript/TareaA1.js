// Ejercicio 1: Pedir al usuario su nombre y saludarlo.
//Inicio del programa
//    Escribir "Por favor ingresa tu nombre:"  // Entrada de datos
//    Leer nombre  // Proceso de entrada
//    Escribir "Hola, " + nombre + "!"  // Salida de datos con saludo
//Fin del programa


// Pedir al usuario su nombre
var n = prompt("Por favor, ingresa tu nombre:");

// Saludar al usuario
alert("¡Hola, " + n + "! Bienvenido.");