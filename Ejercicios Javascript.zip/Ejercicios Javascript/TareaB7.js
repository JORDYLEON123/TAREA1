// Ejercicio 7: Pedir dos nombres e indicar si son iguales, si el primero es mayor o menor que el segundo.
//Inicio del programa
//    Escribir "Por favor ingresa el primer nombre:"  // Entrada de datos
//    Leer nombre1  // Proceso de entrada
//    Escribir "Por favor ingresa el segundo nombre:"  // Entrada de datos
//    Leer nombre2  // Proceso de entrada
//    Si nombre1 == nombre2 entonces  // Proceso de comparación
//        Escribir "Los nombres son iguales."  // Salida de datos
//    Sino si nombre1 > nombre2 entonces
//        Escribir nombre1 + " es mayor que " + nombre2  // Salida de datos
//    Sino
//        Escribir nombre1 + " es menor que " + nombre2  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario dos nombres
var n1 = prompt("Ingrese el primer nombre:");
var n2 = prompt("Ingrese el segundo nombre:");

// Comparar los nombres y mostrar el resultado
if (n1 === n2) {
    alert("Los nombres son iguales.");
} else if (n1 < n2) {
    alert("El primer nombre es menor que el segundo en orden alfabético.");
} else {
    alert("El primer nombre es mayor que el segundo en orden alfabético.");
}
