// Ejercicio 3: Solicitar al usuario dos números y mostrar su suma.
//Inicio del programa
//    Escribir "Por favor ingresa el primer número:"  // Entrada de datos
//    Leer num1  // Proceso de entrada
//    Escribir "Ahora ingresa el segundo número:"  // Entrada de datos
//    Leer num2  // Proceso de entrada
//    suma = num1 + num2  // Proceso de sumar los números
//    Escribir "La suma de los números es: " + suma  // Salida de datos con la suma
//Fin del programa

// Solicitar al usuario dos números
var n1 = parseFloat(prompt("Ingrese el primer número:"));
var n2 = parseFloat(prompt("Ingrese el segundo número:"));

// Calcular la suma de los números
var s = n1 + n2;

// Mostrar la suma
alert("La suma de los números es: " + s);