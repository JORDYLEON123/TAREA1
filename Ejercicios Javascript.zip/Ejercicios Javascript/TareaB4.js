// Ejercicio 4: Solicitar al usuario un número y mostrar si es positivo o negativo.
//Inicio del programa
//    Escribir "Por favor ingresa un número:"  // Entrada de datos
//    Leer numero  // Proceso de entrada
//    Si numero > 0 entonces  // Proceso de determinar signo
//        Escribir "El número es positivo."  // Salida de datos
//    Sino si numero < 0 entonces
//        Escribir "El número es negativo."  // Salida de datos
//    Sino
//        Escribir "El número es cero."  // Salida de datos
//    Fin Si
//Fin del programa


// Solicitar al usuario un número
var n = parseFloat(prompt("Ingrese un número:"));

// Verificar si el número es positivo, negativo o cero y mostrar el resultado
if (n > 0) {
    alert("El número ingresado es positivo.");
} else if (n < 0) {
    alert("El número ingresado es negativo.");
} else {
    alert("El número ingresado es cero.");
}
